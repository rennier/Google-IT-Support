## Resources

<br>

* https://www.cisco.com/c/en/us/td/docs/security/security_management/cisco_security_manager/security_manager/4-1/user/guide/CSMUserGuide_wrapper/fwaccess.html
* https://www.juniper.net/documentation/en_US/junos/topics/usage-guidelines/services-configuring-stateful-firewall-rules.html
* https://www.digitalocean.com/community/tutorials/iptables-essentials-common-firewall-rules-and-commands
* https://www.digitalocean.com/community/tutorials/ufw-essentials-common-firewall-rules-and-commands
* https://en.wikipedia.org/wiki/IEEE_802.1X
* http://www.haproxy.org/#docs
* http://cbonte.github.io/haproxy-dconv/1.8/intro.html#3.3.1
* http://nginx.org/en/docs/
* http://nginx.org/en/docs/beginners_guide.html#proxy
* http://httpd.apache.org/docs/
* https://httpd.apache.org/docs/2.4/howto/reverse_proxy.html
* https://doi.org/10.1007/3-540-45537-X_1
* https://www.kb.cert.org/vuls/id/723755
* https://it.awroblew.biz/linux-how-to-checkenable-promiscuous-mode/
* https://danielmiessler.com/blog/entering-promiscuous-mode-os-x/
* http://lifeofageekadmin.com/how-to-manually-change-your-nic-to-promiscuous-mode-on-windows-72008-r2/
* https://www.snort.org/
* https://suricata-ids.org/
* https://www.zeek.org/