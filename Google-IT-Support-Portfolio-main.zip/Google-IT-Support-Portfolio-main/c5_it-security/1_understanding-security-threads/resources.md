## Resources

<br>

* http://www.independent.co.uk/news/business/news/disgruntled-worker-tried-to-cripple-ubs-in-protest-over-32000-bonus-481515.html
* https://threatpost.com/major-dns-cache-poisoning-attack-hits-brazilian-isps-110711/75859/
* https://dyn.com/blog/dyn-analysis-summary-of-friday-october-21-attack/


