## Resources

<br>

* https://en.wikipedia.org/wiki/Integer_factorization
* http://www.rc4nomore.com/
* https://nakedsecurity.sophos.com/2012/10/25/sony-ps3-hacked-for-good-master-keys-revealed/
* https://www.theguardian.com/technology/gamesblog/2011/jan/07/playstation-3-hack-ps3
* https://eprint.iacr.org/2005/010
* https://www.schneier.com/blog/archives/2005/02/sha1_broken.html
* https://eprint.iacr.org/2007/474
* https://shattered.io/
* https://www.ietf.org/rfc/rfc5280.txt
* http://www.philzimmermann.com/EN/essays/WhyIWrotePGP.html
* https://tools.ietf.org/html/rfc3193
* https://openvpn.net/index.php/open-source.html
* https://gcn.com/Articles/2010/02/02/Black-Hat-chip-crack-020210.aspx