## Life of a Process

<br>

### Question 1

True or false: Windows processes can operate independently of their parents.

* **TRUE**
* FALSE

> Unlike in Linux, after a child process is created in Windows and inherits its parent's environment, the parent process can be terminated and the child will continue to run.