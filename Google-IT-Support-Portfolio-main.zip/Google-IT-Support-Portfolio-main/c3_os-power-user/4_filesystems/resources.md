## Resources

<br>

* https://support.microsoft.com/en-us/help/154997/description-of-the-fat32-file-system
* https://support.microsoft.com/en-us/help/140365/default-cluster-size-for-ntfs--fat--and-exfat
* https://technet.microsoft.com/en-us/library/cc766465(v=ws.10).aspx
* https://en.wikipedia.org/wiki/Fstab
* https://en.wikipedia.org/wiki/Paging#Windows_NT
* https://support.microsoft.com/en-us/help/2860880/how-to-determine-the-appropriate-page-file-size-for-64-bit-versions-of
* https://access.redhat.com/documentation/en-US/Red_Hat_Enterprise_Linux/6/html/Installation_Guide/s2-diskpartrecommend-ppc.html#id4394007
* https://msdn.microsoft.com/en-us/library/windows/desktop/aa365006(v=vs.85).aspx
* https://msdn.microsoft.com/en-us/library/windows/desktop/aa363878(v=vs.85).aspx
* https://msdn.microsoft.com/en-us/library/windows/desktop/aa365006(v=vs.85).aspx
* https://docs.microsoft.com/en-us/sysinternals/downloads/du
* https://support.microsoft.com/en-us/help/181701/how-to-start-disk-cleanup-by-using-the-command-line
* https://www.howtogeek.com/115229/htg-explains-why-linux-doesnt-need-defragmenting/
* https://en.wikipedia.org/wiki/Fsck