## Resources

<br>

* https://about.gitlab.com/2017/02/01/gitlab-dot-com-database-incident/
* https://support.microsoft.com/en-us/help/17127/windows-back-up-restore
* https://support.apple.com/en-us/HT201250
* https://wiki.archlinux.org/index.php/rsync#As_a_backup_utility
* https://en.wikipedia.org/wiki/Standard_RAID_levels