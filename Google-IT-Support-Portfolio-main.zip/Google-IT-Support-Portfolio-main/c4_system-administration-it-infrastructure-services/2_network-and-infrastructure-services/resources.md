## Resources

<br>

* https://www.techrepublic.com/blog/the-enterprise-cloud/side-by-side-comparisons-of-iaas-service-providers/
* https://en.wikipedia.org/wiki/Network_as_a_service
* http://www.businessinsider.com/the-most-popular-cloud-apps-used-at-work-2015-8
* http://www.tomsitpro.com/articles/paas-providers,1-1517.html
* https://www.pcworld.idg.com.au/article/151491/server_operating_systems/
* https://en.wikipedia.org/wiki/OpenSSH
* https://docs.microsoft.com/en-us/windows-server/remote/remote-desktop-services/clients/remote-desktop-clients
* https://msdn.microsoft.com/en-us/library/aa384291(v=vs.85).aspx
* https://en.wikipedia.org/wiki/PuTTY

Supplemental Reading for FTP Clients
For more information on PXE Boot click https://en.wikipedia.org/wiki/Preboot_Execution_Environment and for FTP Clients click https://en.wikipedia.org/wiki/Comparison_of_FTP_client_software

Supplemental Reading for BIND/PowerDNS
For more information on BIND/PowerDNS Readings click https://blog.dnsimple.com/2015/02/top-dns-servers/

Supplemental Reading for DNS and DHCP
For more information on DNS Software click https://blog.dnsimple.com/2015/02/top-dns-servers/ and for DHCP Software click https://en.wikipedia.org/wiki/Comparison_of_DHCP_server_software.