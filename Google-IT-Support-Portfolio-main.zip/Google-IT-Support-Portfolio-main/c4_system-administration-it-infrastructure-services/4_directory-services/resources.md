## Resources

<br>

* https://en.wikipedia.org/wiki/Role-based_access_control
* https://www.chef.io/chef/
* https://puppet.com/
* https://docs.microsoft.com/en-us/sccm/core/understand/introduction
* https://en.wikipedia.org/wiki/LDAP_Data_Interchange_Format
* https://technet.microsoft.com/en-us/library/cc780469(v=ws.10).aspx
* https://technet.microsoft.com/en-us/library/cc961936.aspx
* https://technet.microsoft.com/en-us/library/cc755692(v=ws.10).aspx
* https://technet.microsoft.com/en-us/library/cc780957%28v=ws.10%29.aspx?f=255&MSPPError=-2147217396
* https://technet.microsoft.com/en-us/library/cc962100.aspx
* https://docs.microsoft.com/en-us/windows-server/identity/ad-ds/active-directory-functional-levels
* https://www.digitalocean.com/community/tutorials/how-to-install-and-configure-openldap-and-phpldapadmin-on-ubuntu-16-04
* https://www.openldap.org/doc/admin24/slapdconf2.html
* https://en.wikipedia.org/wiki/LDAP_Data_Interchange_Format
* https://www.digitalocean.com/community/tutorials/how-to-use-ldif-files-to-make-changes-to-an-openldap-system