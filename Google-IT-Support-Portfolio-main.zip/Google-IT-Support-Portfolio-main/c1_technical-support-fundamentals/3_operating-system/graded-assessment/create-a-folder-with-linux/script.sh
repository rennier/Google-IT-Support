#/usr/bin/bash

mkdir my-folder