## Create a Folder with Linux

Now you will do the exact same thing that you did for the Windows lab but for the Linux operating system!

### What you’ll do

There are two learning objectives for this lab:

* Familiarize yourself with the Qwiklabs environment and log into the Google Cloud Console
* Access a Linux VM instance and create a basic file using the command line interface.