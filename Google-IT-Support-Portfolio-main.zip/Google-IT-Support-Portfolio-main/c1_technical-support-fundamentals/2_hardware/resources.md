## Resources

<br>

* https://en.wikipedia.org/wiki/CPU_cache
* https://www.digitaltrends.com/computing/how-to-overclock-your-cpu/3/
* https://support.microsoft.com/en-us/help/15056/windows-7-32-64-bit-faq
* https://en.wikipedia.org/wiki/64-bit_computing#32-bit_vs_64-bit%E2%80%A6
* https://en.wikipedia.org/wiki/Kilobyte
* https://en.wikipedia.org/wiki/Inductive_charging
* https://docs.microsoft.com/windows-hardware/design/device-experiences/powercfg-command-line-options#option_batteryreport
* https://support.apple.com/HT201585
* https://www.osha.gov/dts/shib/shib011819.html
* https://www.apple.com/batteries/maximizing-performance/
* https://support.google.com/android/answer/7664358
* https://en.wikipedia.org/wiki/USB
* https://en.wikipedia.org/wiki/VGA_connector
* https://en.wikipedia.org/wiki/Digital_Visual_Interface#Connector
* https://en.wikipedia.org/wiki/HDMI#Connectors
* https://en.wikipedia.org/wiki/DisplayPort#Full-size_DisplayPort_connector
* https://support.microsoft.com/help/27911/windows-10-connect-to-a-projector-or-pc
* https://support.apple.com/guide/mac-help/mchl5fdd37ce/mac
* https://help.ubuntu.com/stable/ubuntu-help/display-dual-monitors.html
* https://en.wikipedia.org/wiki/Keystone_effect