## Resources

<br>

* https://simple.wikipedia.org/wiki/Logic_gate.