## Resources

<br>

* http://www.wired.co.uk/article/internet-of-things-what-is-explained-iot