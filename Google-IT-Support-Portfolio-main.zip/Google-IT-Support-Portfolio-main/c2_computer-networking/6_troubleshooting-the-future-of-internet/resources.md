## Resources

<br>

* https://en.wikipedia.org/wiki/Netcat
* https://docs.microsoft.com/powershell/module/nettcpip/test-netconnection
* https://en.wikipedia.org/wiki/6in4
* https://en.wikipedia.org/wiki/Tunnel_Setup_Protocol
* https://en.wikipedia.org/wiki/Anything_In_Anything