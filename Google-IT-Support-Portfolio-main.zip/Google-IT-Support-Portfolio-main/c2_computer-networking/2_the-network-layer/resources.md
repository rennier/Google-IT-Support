## Resources

* https://www.ietf.org/
* https://en.wikipedia.org/wiki/Routing_Information_Protocol
* https://tools.ietf.org/html/rfc2453
* https://en.wikipedia.org/wiki/Enhanced_Interior_Gateway_Routing_Protocol
* https://www.cisco.com/c/en/us/support/docs/ip/enhanced-interior-gateway-routing-protocol-eigrp/16406-eigrp-toc.html
* https://en.wikipedia.org/wiki/Open_Shortest_Path_First
* https://tools.ietf.org/html/rfc2328
* https://en.wikipedia.org/wiki/Border_Gateway_Protocol
* https://www.ietf.org/
* https://www.ietf.org/standards/rfcs/
* https://en.wikipedia.org/wiki/April_Fools%27_Day_Request_for_Comments
* https://tools.ietf.org/html/rfc1149
* https://www.ietf.org/rfc/rfc3514.txt